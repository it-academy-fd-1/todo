import { View } from "./View";

export class CounterView extends View {

    increase(callback) {
        this.el.addEventListener('click', (evt) => {
            if(evt.target.closest('.plus')) {
                callback()
            }
        })
    }

    decrease(callback) {
        this.el.addEventListener('click', (evt) => {
            if(evt.target.closest('.minus')) {
                callback()
            }
        })
    }

    render(state) {
        return `
            <div class="flex text-red-500 text-indigo-500 text-blue-500 text-red-500">
                <button class="plus text-white p-2 border border-white">+</button>
                <p class="${state.counterModel.activeColor} p-2">${state.counterModel.count}</p>
                <button class="minus text-white p-2 border border-white">-</button>
            </div>
        `
    }
}