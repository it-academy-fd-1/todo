export class CountController {
    constructor(models, counterView) {
        this.counterModel = models.counterModel;
        this.counterView = counterView;

        this.counterView.increase(() => {
            this.counterModel.increase()
            this.counterModel.setRandomColor()
        });

        this.counterView.decrease(() => {
            this.counterModel.decrease();
            this.counterModel.setRandomColor()
        });
    }
}