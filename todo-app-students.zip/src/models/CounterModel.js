import { Model } from "./Model";

export class CounterModel extends Model {
    increase() {
        this.setState({ ...this.state, count: this.state.count + 1 })
    }
    
    decrease() {
        this.setState({ ...this.state, count: this.state.count - 1 })
    }

    setRandomColor() {
        const length = this.state.colors.length - 1
        const color = Math.round(Math.random() *  length);
        this.setState({ ...this.state, activeColor: this.state.colors[color] })
    }
}