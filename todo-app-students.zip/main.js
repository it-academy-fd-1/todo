import { CountController } from './src/controllers/CountController';
import { CounterModel } from './src/models/CounterModel';
import { CounterView } from './src/views/CounterView';
import './style.css'

const root = document.querySelector('#root');

// Containers
const counterContainer = document.createElement('div');
root.append(counterContainer);
// Containers

// Models
const counterModel = new CounterModel({ 
    count: 0, 
    colors: ['text-red-500', 'text-indigo-500', 'text-blue-500', 'text-red-500'], 
    activeColor: 'text-white' 
});
// Models

// Views
const counterView = new CounterView(counterContainer, { counterModel })
// Views


// Controllers
new CountController({ counterModel }, counterView)
// Controllers
