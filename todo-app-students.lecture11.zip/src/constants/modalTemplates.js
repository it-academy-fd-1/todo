export const MODAL_TEMPLATES = {
  todoFormTemplate: "todoFormTemplate",
};
