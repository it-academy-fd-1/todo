import { MODAL_TEMPLATES } from "../constants/modalTemplates";

export class TodoController {
  constructor(models, view) {
    this.view = view;
    this.todoModel = models.todoModel;
    this.modalModel = models.modalModel;

    this.openCreateTaskModal();
  }

  openCreateTaskModal() {
    this.view.openCreateTaskModal(() => {
      this.modalModel.open(MODAL_TEMPLATES.todoFormTemplate, {
        isOpen: true,
      });
    });
  }
}
