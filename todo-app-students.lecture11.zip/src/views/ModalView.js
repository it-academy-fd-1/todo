import { View } from "./View";

export class ModalView extends View {
  render({ modalModel }) {
    const { template, data } = modalModel;

    if (!data.isOpen) return "";

    return `
        <h1>Modal</h1>
    `;
  }
}
