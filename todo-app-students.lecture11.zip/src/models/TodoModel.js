import { Model } from './Model';


export class TodoModel extends Model {}